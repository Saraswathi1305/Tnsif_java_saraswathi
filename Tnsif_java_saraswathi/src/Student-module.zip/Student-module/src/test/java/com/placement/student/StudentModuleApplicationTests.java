package com.placement.student;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentModuleApplicationTests {

	@Test
	void contextLoads() {
	}

}
